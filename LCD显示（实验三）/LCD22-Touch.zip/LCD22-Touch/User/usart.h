#ifndef __USART_H
#define __USART_H
#include "stm32f0xx.h"

#include <stdio.h>


void USART_Configuration(void );
#endif /* __USART_H */

